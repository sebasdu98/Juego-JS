function empezar() {
	location.href="fondo.html";
}
function salir(){
	location.href="menu.html";
}
setInterval(score,900);
var x=280;
var y=420;
var t=0;

var imgm = new Image();
imgm.src = "imagenes/meteoro.png";

var xm=Math.floor(Math.random() * (575 - 0 + 1)) + 0;
var ym=50;

var xm2=Math.floor(Math.random() * (575 - 0 + 1)) + 0;
var ym2=50;

var xm3=Math.floor(Math.random() * (575 - 0 + 1)) + 0;
var ym3=50;

var xm4=Math.floor(Math.random() * (575 - 0 + 1)) + 0;
var ym4=50;


function nave(){
	var canvas = document.getElementById("canvas");
	var ctx = canvas.getContext("2d");
	ctx.font= "20px Arial ";
	ctx.fillStyle = 'yellow';
	var img = new Image();
	img.src = "imagenes/nave.png";
	img.onload = function(){
		ctx.clearRect(0,0,640,480);
		console.log(x,y);
		console.log(xm,ym);
		ctx.drawImage(img, x, y);
		ctx.drawImage(imgm, xm, ym);
		ctx.fillText("Puntaje: ",380,50);
		ctx.font = "25px Times New Roman ";
		ctx.fillStyle = 'green';
		ctx.fillText(t,490,50);
		if (t>150) {
			cambioesc1();
			ctx.drawImage(imgm, xm2, ym2);
			if(t>250){
				cambioesc2();
				ctx.drawImage(imgm, xm3, ym3);
				ctx.drawImage(imgm, xm4, ym4);
			}
		}

	}

}

function score(){
	t=t+10;
	return t;
}

function cambioesc1(){
  document.getElementById("canvas").style.background = "url('fondo2.png') no-repeat ";
}
function cambioesc2(){
	document.getElementById("canvas").style.background = "url('fondo3.png') no-repeat";
}
function cambio(event){

	if(event.keyCode=='39'){//si la tecla presionada es direccional derecho
			x=x+5;//mueve la nave 5 pixeles a la derecha
			ym=ym+5;
			ym2=ym2+15;
			ym3=ym3+20;
			ym4=ym4+25;
			if (x>575) {
				x=x-5;
			} 
			if(ym>420){
				ym=50;
				xm=Math.floor(Math.random() * (575 - 0 + 1)) + 0;
			}
			if(ym2>420){
				ym2=50;
				xm2=Math.floor(Math.random() * (575 - 0 + 1)) + 0;
			}
			if(ym3>420){
				ym3=50;
				xm3=Math.floor(Math.random() * (575 - 0 + 1)) + 0;
			}
			if(ym4>420){
				ym4=50;
				xm4=Math.floor(Math.random() * (575 - 0 + 1)) + 0;
			}
			nave();
	}

	if(event.keyCode=='37'){//si la tecla presionada es direccional izquierdo
			x=x-5;//mueve la nave 5 pixeles a la izquierda
			ym=ym+5;
			ym2=ym2+15;
			ym3=ym3+20;
			ym4=ym4+25;
			if (x<0) {
				x=x+5;
			} 
			if(ym>420){
				ym=50;
				xm=Math.floor(Math.random() * (575 - 0 + 1)) + 0;
			}
			if(ym2>420){
				ym2=50;
				xm2=Math.floor(Math.random() * (575 - 0 + 1)) + 0;
			}
			if(ym3>420){
				ym3=50;
				xm3=Math.floor(Math.random() * (575 - 0 + 1)) + 0;
			}
			if(ym4>420){
				ym4=50;
				xm4=Math.floor(Math.random() * (575 - 0 + 1)) + 0;
			}
			nave();
	}

	if(event.keyCode=='38'){//si la tecla presionada es direccional arriba
			y=y-5;//sube la nave
			ym=ym+5;
			ym2=ym2+15;
			ym3=ym3+20;
			ym4=ym4+25;
			if (y<50) {
				y=y+5;
			}
			if(ym>420){
				ym=50;
				xm=Math.floor(Math.random() * (575 - 0 + 1)) + 0;
			}
			if(ym2>420){
				ym2=50;
				xm2=Math.floor(Math.random() * (575 - 0 + 1)) + 0;
			}
			if(ym3>420){
				ym3=50;
				xm3=Math.floor(Math.random() * (575 - 0 + 1)) + 0;
			}
			if(ym4>420){
				ym4=50;
				xm4=Math.floor(Math.random() * (575 - 0 + 1)) + 0;
			}
			nave();
	}

	if(event.keyCode=='40'){// si la tecla presionada es direccional abajo
			y=y+5;//baja la nave
			ym=ym+5;
			ym2=ym2+15;
			ym3=ym3+20;
			ym4=ym4+25;
			if (y>=420) {
				y=y-5;
			}
			if(ym>420){
				ym=50;
				xm=Math.floor(Math.random() * (575 - 0 + 1)) + 0;
			}
			if(ym2>420){
				ym2=50;
				xm2=Math.floor(Math.random() * (575 - 0 + 1)) + 0;
			}
			if(ym3>420){
				ym3=50;
				xm3=Math.floor(Math.random() * (575 - 0 + 1)) + 0;
			}
			if(ym4>420){
				ym4=50;
				xm4=Math.floor(Math.random() * (575 - 0 + 1)) + 0;
			}
			nave();
	}
	}